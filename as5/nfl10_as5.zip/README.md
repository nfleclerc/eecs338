compile with $ make
run with $ ./main.o
