#include "common.h"

#ifndef SEMAPHORE_WRITER
#define SEMAPHORE_WRITER
void *writer(void *shared);
#endif
