running make will make the rpc files first.
just run mother with ./mother then
./judy and then ./tina and it should all work

judy and tina take as arguments the host that theyre being run on. for the 
sample output test i just did this on localhost, but it should work over the
network just fine
