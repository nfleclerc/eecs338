make to compile
./As4.o to run

it used to run nearly perfectly but i went to fix my array list implementation and somewhere along the line, i seem to have messed up and it doesnt seem to be waiting correctly on the wlist semaphore or something like that. it goes straight to saying that enough funds have been deposited
